#!/usr/bin/env python3
"""
Grad Jobs London: a small local web app that checks job boards for new
graduate roles in London and lets you track them.

    pip install -r requirements.txt
    python app.py
    then open http://127.0.0.1:5000
"""
import copy
import json
import smtplib
import sqlite3
import threading
import time
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape
from pathlib import Path

from flask import Flask, jsonify, render_template, request

import scanner

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
DATA.mkdir(exist_ok=True)
DB_PATH = DATA / "jobs.db"
SETTINGS_PATH = DATA / "settings.json"
STATUSES = {"new", "seen", "saved", "applied", "hidden"}
LIST_KEYS = ["greenhouse", "lever", "ashby", "smartrecruiters", "jsonld_pages",
             "search_terms", "include", "exclude", "locations", "location_exclude"]

app = Flask(__name__)
state = {"running": False, "last_run": None, "last_new": 0, "log": []}
scan_lock = threading.Lock()


# ------------------------------------------------------------- storage

def load_settings():
    s = copy.deepcopy(scanner.DEFAULT_SETTINGS)
    if SETTINGS_PATH.exists():
        saved = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
        email = {**s["email"], **saved.pop("email", {})}
        s.update(saved)
        s["email"] = email
    return s


def save_settings(s):
    SETTINGS_PATH.write_text(json.dumps(s, indent=2), encoding="utf-8")


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE, company TEXT, title TEXT, location TEXT,
            url TEXT, posted TEXT, source TEXT,
            first_seen TEXT, status TEXT DEFAULT 'new')""")


# ------------------------------------------------------------- scanning

def send_email(s, jobs):
    e = s["email"]
    rows = "".join(
        f"<tr><td style='padding:6px 10px'>{escape(j['company'])}</td>"
        f"<td style='padding:6px 10px'><a href='{escape(j['url'])}'>{escape(j['title'])}</a></td>"
        f"<td style='padding:6px 10px'>{escape(j['location'])}</td></tr>" for j in jobs)
    body = (f"<h2 style='font-family:sans-serif'>{len(jobs)} new graduate "
            f"job{'s' if len(jobs) != 1 else ''} in London</h2>"
            f"<table style='font-family:sans-serif;border-collapse:collapse'>{rows}</table>")
    to = [a.strip() for a in e["to"].split(",") if a.strip()]
    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"{len(jobs)} new graduate job{'s' if len(jobs) != 1 else ''} in London"
    msg["From"] = e["username"]
    msg["To"] = ", ".join(to)
    msg.attach(MIMEText(body, "html"))
    with smtplib.SMTP(e["smtp_host"], int(e["smtp_port"]), timeout=30) as smtp:
        smtp.starttls()
        smtp.login(e["username"], e["password"])
        smtp.sendmail(e["username"], to, msg.as_string())


def do_scan():
    if not scan_lock.acquire(blocking=False):
        return
    state["running"] = True
    state["log"] = []
    log = lambda line: state["log"].append(line)
    try:
        s = load_settings()
        found = scanner.run_scan(s, log)
        now = datetime.now(timezone.utc).isoformat()
        new = []
        with db() as con:
            for j in found:
                cur = con.execute(
                    "INSERT OR IGNORE INTO jobs (key, company, title, location, url, posted,"
                    " source, first_seen) VALUES (?,?,?,?,?,?,?,?)",
                    (j["key"], j["company"], j["title"], j["location"], j["url"],
                     j["posted"], j["source"], now))
                if cur.rowcount:
                    new.append(j)
        log(f"{len(new)} new role{'s' if len(new) != 1 else ''} added.")
        if new and s["email"]["enabled"]:
            try:
                send_email(s, new)
                log("Email digest sent.")
            except Exception as e:
                log(f"Email failed ({e}). Check the email settings.")
        state["last_new"] = len(new)
    except Exception as e:
        log(f"Check failed ({e})")
    finally:
        state["last_run"] = datetime.now(timezone.utc).isoformat()
        state["running"] = False
        scan_lock.release()


def scheduler():
    """Background loop: check on the interval set in Settings."""
    last = 0.0
    while True:
        minutes = max(15, int(load_settings().get("check_every_minutes") or 60))
        if time.time() - last >= minutes * 60:
            last = time.time()
            do_scan()
        time.sleep(30)


# ------------------------------------------------------------- routes

@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/jobs")
def api_jobs():
    with db() as con:
        rows = con.execute("SELECT * FROM jobs ORDER BY first_seen DESC, company").fetchall()
    return jsonify([dict(r) for r in rows])


@app.post("/api/jobs/<int:job_id>/status")
def api_set_status(job_id):
    status = (request.get_json(silent=True) or {}).get("status")
    if status not in STATUSES:
        return jsonify(error="Unknown status"), 400
    with db() as con:
        con.execute("UPDATE jobs SET status=? WHERE id=?", (status, job_id))
    return jsonify(ok=True)


@app.post("/api/jobs/mark-read")
def api_mark_read():
    with db() as con:
        con.execute("UPDATE jobs SET status='seen' WHERE status='new'")
    return jsonify(ok=True)


@app.post("/api/check")
def api_check():
    if not state["running"]:
        threading.Thread(target=do_scan, daemon=True).start()
    return jsonify(ok=True)


@app.get("/api/status")
def api_status():
    return jsonify(running=state["running"], last_run=state["last_run"],
                   last_new=state["last_new"], log=state["log"],
                   interval=load_settings().get("check_every_minutes"))


@app.get("/api/settings")
def api_get_settings():
    s = load_settings()
    s["email"] = {**s["email"], "password": "", "has_password": bool(s["email"]["password"])}
    return jsonify(s)


@app.post("/api/settings")
def api_save_settings():
    incoming = request.get_json(silent=True) or {}
    s = load_settings()
    for k in LIST_KEYS:
        if k in incoming:
            s[k] = [x.strip() for x in incoming[k] if str(x).strip()]
    for k in ["adzuna_app_id", "adzuna_app_key", "reed_api_key", "search_location"]:
        if k in incoming:
            s[k] = str(incoming[k]).strip()
    if "check_every_minutes" in incoming:
        try:
            s["check_every_minutes"] = max(15, int(incoming["check_every_minutes"]))
        except (TypeError, ValueError):
            pass
    e = incoming.get("email") or {}
    for k in ["enabled", "smtp_host", "smtp_port", "username", "to"]:
        if k in e:
            s["email"][k] = e[k]
    if e.get("password"):            # blank means "keep the existing password"
        s["email"]["password"] = e["password"]
    save_settings(s)
    return jsonify(ok=True)


if __name__ == "__main__":
    init_db()
    threading.Thread(target=scheduler, daemon=True).start()
    print("\n  Grad Jobs London is running: open http://127.0.0.1:5000\n")
    app.run(host="127.0.0.1", port=5000, debug=False)
