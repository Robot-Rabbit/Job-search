# London grad jobs

A small web app that runs on your computer, checks company job boards and UK
job sites for new graduate roles in London, and lets you save roles, mark
applications and hide the ones you're not interested in.

## Set up (once)

1. Install Python 3.10 or newer from python.org (on Windows, tick "Add Python to PATH").
2. Open a terminal in this folder and run:

       pip install -r requirements.txt

## Run it

    python app.py

Then open http://127.0.0.1:5000 in your browser. Leave the terminal window
open: the app checks for new roles automatically while it's running.

## First steps in the app

1. Open **Settings**.
2. Add companies to watch. Open a company's careers page, click on a job, and
   look at the web address:
   - boards.greenhouse.io/**name** or job-boards.greenhouse.io/**name** -> Greenhouse
   - jobs.lever.co/**name** -> Lever
   - jobs.ashbyhq.com/**name** -> Ashby
   - jobs.smartrecruiters.com/**name** -> SmartRecruiters
3. Optional but recommended: add free API keys from developer.adzuna.com and
   reed.co.uk/developers for wide coverage of UK employers.
4. Click **Save and check now**. The "Last check" box shows what each source
   returned; a failure usually means the company name is wrong or the
   company uses a different job board.

The first check treats every matching role as new. After that, only freshly
posted roles show up as new (highlighted).

## Email alerts

Settings -> tick "Email me when new roles appear". For Gmail, turn on 2-step
verification and create an App Password (Google Account -> Security ->
App passwords). Use that, not your normal password.

## Your data

Everything is stored in the `data` folder next to app.py: `jobs.db` holds
the roles and their status, `settings.json` holds your settings (including
keys and the email app password, so don't share that file). Delete the
folder to start fresh.
